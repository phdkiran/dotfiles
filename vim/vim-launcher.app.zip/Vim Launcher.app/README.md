# Vim Launcher

Icon designed by Jason Long
https://github.com/jasonlong/vim-replacement-icon

Automator script by Glenn Hoppe
http://superuser.com/a/139949 

Compiled into Application by Roman Zolotarev
https://github.com/romanzolotarev/dotfiles
